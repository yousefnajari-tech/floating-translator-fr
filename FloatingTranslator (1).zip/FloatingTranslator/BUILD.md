# راهنمای ساخت فایل APK از پروژه مترجم شناور

پروژه یک پروژه‌ی استاندارد Gradle/Android است. دو راه برای ساخت APK دارید:

---

## 🟢 راه ساده: Android Studio (توصیه می‌شود)

این روش برای اکثر کاربران بهتر است چون Android Studio به‌صورت خودکار JDK، Android SDK و Gradle را تنظیم می‌کند.

### مرحله ۱ — نصب پیش‌نیازها
1. **Android Studio** را از [سایت رسمی](https://developer.android.com/studio) دانلود و نصب کنید (نسخه Hedgehog 2023.1.1 یا جدیدتر).
2. هنگام نصب، اجازه دهید Android SDK خودش دانلود شود (حدود 1-2GB).

### مرحله ۲ — باز کردن پروژه
1. پوشه‌ی `FloatingTranslator` را که همین‌الان ساخته شده، به کامپیوتر خودتان منتقل کنید (زیپ کنید یا با git بکشید).
2. Android Studio را باز کنید → `File → Open...`
3. پوشه‌ی `FloatingTranslator` را انتخاب کنید و **روی پوشه‌ی خودِ پروژه** کلیک کنید (جایی که فایل `build.gradle.kts` و `settings.gradle.kts` قرار دارد).
4. منتظر بمانید اندروید استودیو خودش Gradle را sync کند (ممکن است چند دقیقه طول بکشد و اینترنت نیاز داشته باشد تا dependency ها را دانلود کند).

### مرحله ۳ — ساخت APK قابل نصب (debug)
1. از منوی بالای Android Studio: `Build → Build Bundle(s) / APK(s) → Build APK(s)`
2. پس از اتمام، یک اعلان پایین صفحه می‌آید → روی `locate` کلیک کنید.
3. فایل `app-debug.apk` در مسیر زیر ساخته شده:
   ```
   FloatingTranslator/app/build/outputs/apk/debug/app-debug.apk
   ```

### مرحله ۴ — نصب روی گوشی
1. در گوشی **Developer Options** را فعال کنید (7 بار روی Build Number در تنظیمات بزنید).
2. **USB debugging** را روشن کنید.
3. گوشی را با USB به کامپیوتر وصل کنید (یا از Wireless Debugging استفاده کنید).
4. روی دکمه‌ی سبز ▶️ در نوار بالای Android Studio بزنید → اپ مستقیم روی گوشی نصب و اجرا می‌شود.
   - یا فایل APK را به گوشی منتقل کرده و با ضربه روی آن نصب کنید.

### (اختیاری) ساخت APK امضاشده برای انتشار (release)
1. `Build → Generate Signed Bundle / APK...`
2. `APK` را انتخاب کنید → Next
3. یک keystore جدید بسازید یا از keystore موجود استفاده کنید (حتماً پسوردها را یادداشت کنید).
4. Build variant `release` را انتخاب و دو گزینه `V1 (Jar Signature)` و `V2 (Full APK Signature)` را تیک بزنید.
5. Finish → APK امضاشده در `app/release/` ساخته می‌شود.

---

## 🔵 راه پیشرفته: ساخت از خط فرمان (بدون Android Studio)

اگر ترجیح می‌دهید از ترمینال استفاده کنید:

### ۱) نصب پیش‌نیازها
- **JDK 17** را نصب کنید:
  - Windows: از [Adoptium Temurin 17](https://adoptium.net/)
  - macOS: `brew install openjdk@17`
  - Linux: `sudo apt install openjdk-17-jdk`
- **Android SDK** (command line tools) را از [سایت رسمی](https://developer.android.com/studio#command-line-tools-only) دانلود کنید.
- متغیرهای محیطی را تنظیم کنید:
  ```bash
  export ANDROID_HOME=$HOME/Android/Sdk       # یا مسیر دلخواه
  export JAVA_HOME=/path/to/jdk-17
  export PATH=$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH
  ```

### ۲) نصب کامپوننت‌های لازم SDK
```bash
sdkmanager "platforms;android-34" "build-tools;34.0.0" "platform-tools"
```

### ۳) ساخت APK
در پوشه‌ی پروژه (`FloatingTranslator/`):
```bash
# لینوکس / macOS
chmod +x gradlew
./gradlew assembleDebug

# ویندوز (PowerShell یا CMD)
gradlew.bat assembleDebug
```

APK خروجی در این مسیر خواهد بود:
```
app/build/outputs/apk/debug/app-debug.apk
```

### ۴) نصب روی گوشی متصل
```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

---

## 🔧 اسکریپت ساخت سریع

در همین پوشه فایل `build.sh` (برای لینوکس/macOS) و `build.bat` (برای ویندوز) قرار داده شد که مراحل ساخت debug APK را به‌طور خودکار اجرا می‌کنند (به‌شرطی که Android SDK و JDK 17 نصب باشند).

---

## ❌ مشکلات رایج

| مشکل | راه‌حل |
|------|--------|
| `SDK location not found` | فایلی به نام `local.properties` در ریشه پروژه بسازید و داخلش بنویسید: `sdk.dir=/Users/نام‌کاربر/Library/Android/sdk` (مسیر صحیح SDK خودتان) |
| `Gradle sync failed: JDK version` | در Android Studio: `Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK` را روی نسخه 17 بگذارید. |
| `minSdk mismatch` | این پروژه minSdk=29 (اندروید 10) دارد، روی گوشی‌های قدیمی‌تر نصب نمی‌شود. |
| وابسته‌های Vosk دانلود نشدند | مطمئن شوید به اینترنت دسترسی دارید و gradle در حالت آفلاین نیست (Settings → Gradle → Offline work خاموش باشد). |
| در گوشی روی اندروید 13+ مجوز ناتیفیکیشن نمی‌آید | در تنظیمات اپ، دستری Notifications را دستی فعال کنید. |

---

## ✅ بعد از نصب روی گوشی

1. اپ «مترجم شناور زنده» را باز کنید.
2. زبان مبدأ (انگلیسی/اسپانیایی) را انتخاب کنید.
3. موتور تشخیص گفتار را انتخاب کنید:
   - **Vosk (سبک و سریع)** — مدل ۴۰ مگابایتی، بهترین برای گوشی‌های میانه
   - **Whisper v3 Turbo (باکیفیت)** — مدل حدود ۱۵۰-۲۵۰ مگابایتی، بهترین دقت، آفلاین
   - **Google Cloud (آنلاین)** — نیاز به API Key
4. در صورت انتخاب Google Cloud، API Key خود را وارد کنید.
5. روی **«شروع ترجمه زنده»** بزنید.
6. مجوزهای «نمایش روی سایر برنامه‌ها»، «ضبط صدا»، و «اعلان‌ها» را بدهید.
7. صفحه‌ی اجازه‌ی MediaProjection (کپچر اسکرین) نمایش داده می‌شود → روی «Start now» بزنید.
8. پنجره شناور پایین صفحه ظاهر می‌شود. حالا هر ویدیو/صدا که پخش کنید، صدایش به‌صورت زنده تشخیص داده شده و ترجمه فارسی‌اش نمایش داده می‌شود.

> **اولین اجرا با Whisper v3 Turbo**: بسته به سرعت اینترنت، ۱-۳ دقیقه دانلود مدل طول می‌کشد. لطفاً صبر کنید تا پیغام «در حال شنیدن…» نمایش داده شود.
