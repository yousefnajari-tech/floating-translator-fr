@echo off
REM =========================================================
REM  FloatingTranslator — Quick debug build script (Windows)
REM =========================================================

setlocal
cd /d "%~dp0"

echo → Checking Java...
where java >nul 2>&1
if errorlevel 1 (
    echo ERROR: Java not found. Please install JDK 17 and add it to PATH.
    pause
    exit /b 1
)

echo → Checking Android SDK...
if "%ANDROID_HOME%"=="" (
    if exist "%LOCALAPPDATA%\Android\Sdk" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
)
if "%ANDROID_HOME%"=="" (
    echo ERROR: ANDROID_HOME not set. Please install Android SDK or set ANDROID_HOME.
    pause
    exit /b 1
)
echo    Using SDK at: %ANDROID_HOME%

echo → Building debug APK...
call gradlew.bat assembleDebug
if errorlevel 1 (
    echo ❌ Build failed.
    pause
    exit /b 1
)

set APK=app\build\outputs\apk\debug\app-debug.apk
if exist "%APK%" (
    echo.
    echo ✅ Build successful!
    echo APK: %~dp0%APK%
    echo.
    where adb >nul 2>&1
    if not errorlevel 1 (
        echo Installing to connected device...
        adb install -r "%APK%"
    ) else (
        echo adb not found on PATH — copy the APK to your device manually.
    )
) else (
    echo ❌ APK not found at expected location.
)
pause
