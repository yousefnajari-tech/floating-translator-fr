#!/usr/bin/env bash
# =========================================================
#  FloatingTranslator — Quick debug build script (Linux/macOS)
# =========================================================
# Requirements:
#   * JDK 17 installed and on PATH (or JAVA_HOME set)
#   * Android SDK installed with ANDROID_HOME set
#   * Internet connection for first Gradle sync
# =========================================================

set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$PROJECT_DIR"

# ---------- Pre-flight checks ----------
echo "→ Checking Java..."
if ! command -v java >/dev/null 2>&1; then
    echo "ERROR: Java not found. Please install JDK 17."
    exit 1
fi
JAVA_VER=$(java -version 2>&1 | head -1 | sed 's/.*version "\([0-9]*\).*/\1/; 1q')
if [ "$JAVA_VER" -lt 17 ]; then
    echo "WARNING: Detected Java $JAVA_VER. This project requires JDK 17+."
fi

echo "→ Checking Android SDK..."
if [ -z "$ANDROID_HOME" ] && [ -z "$ANDROID_SDK_ROOT" ]; then
    for candidate in "$HOME/Android/Sdk" "$HOME/Library/Android/sdk" "$HOME/AppData/Local/Android/Sdk"; do
        if [ -d "$candidate" ]; then export ANDROID_HOME="$candidate"; break; fi
    done
fi
if [ -z "$ANDROID_HOME" ]; then
    echo "ERROR: ANDROID_HOME not set and SDK not found in common locations."
    echo "       Install Android SDK or set ANDROID_HOME."
    exit 1
fi
echo "   Using SDK at: $ANDROID_HOME"

# ---------- Ensure Gradle wrapper is executable ----------
chmod +x gradlew 2>/dev/null || true

# ---------- Build ----------
echo "→ Building debug APK..."
./gradlew assembleDebug

APK="app/build/outputs/apk/debug/app-debug.apk"
if [ -f "$APK" ]; then
    echo ""
    echo "✅ Build successful!"
    echo "APK: $PROJECT_DIR/$APK"
    echo ""
    if command -v adb >/dev/null 2>&1; then
        DEVICES=$(adb devices | grep -v "List" | grep "device$" | wc -l | tr -d ' ')
        if [ "$DEVICES" -gt 0 ]; then
            echo "Detected $DEVICES connected device(s). Installing..."
            adb install -r "$APK" && echo "✅ Installed successfully!"
        else
            echo "No device connected via ADB (connect a device with USB debugging enabled)."
        fi
    fi
else
    echo "❌ Build failed — see output above."
    exit 1
fi
