# مترجم شناور زنده (Floating Live Translator)

اپلیکیشن اندرویدی که **صدای در حال پخش** از مدیا پلیر (یوتیوب، نتفلیکس، کلاب‌هاوس، و هر اپ دیگری که اجازه ضبط پخش را بدهد) را می‌گیرد، گفتار **انگلیسی** یا **اسپانیایی** را تشخیص می‌دهد و ترجمه‌ی **فارسی** آن را به‌صورت زنده در یک **پنجره شناور** روی تمام اپ‌ها نمایش می‌دهد.

## قابلیت‌ها
- 🎙️ ضبط صدای داخلی (internal audio playback capture) با `AudioPlaybackCapture` مخصوص اندروید 10+ (API 29)
- 🧠 تشخیص گفتار به **سه** صورت (قابل انتخاب در تنظیمات اپ):
  - **آفلاین سبک** با [Vosk](https://alphacephei.com/vosk/) (~40MB مدل، بسیار سریع، مناسب دستگاه‌های ضعیف)
  - **آفلاین با کیفیت بالا** با **Whisper v3 Turbo** از طریق [sherpa-onnx](https://github.com/k2-fsa/sherpa-onnx) (~150-250MB مدل int8، کیفیت نزدیک به سرویس‌های ابری، پشتیبانی عالی از لهجه‌ها)
  - **آنلاین** با Google Cloud Speech-to-Text v1p1beta1 (نیاز به API Key و اینترنت، بهترین کیفیت با تأخیر بسیار کم)
- 🈯 ترجمه‌ی کاملاً آفلاین به فارسی با Google ML Kit On-Device Translation
- 🪟 پنجره شناور draggable که روی همه‌ی اپ‌ها نمایش داده می‌شود
- 🔔 سرویس پیش‌زمینه (Foreground Service) با ناتیفیکیشن قابل کنترل
- ⏱️ تشخیص سکوت برای کاهش پردازش اضافه
- 📺 نمایش متن اصلی + ترجمه فارسی به‌صورت هم‌زمان (partial و final)

## ساختار پروژه
```
app/
├── src/main/
│   ├── AndroidManifest.xml
│   ├── java/com/floatingtranslator/
│   │   ├── MainActivity.kt             // صفحه اصلی، اخذ مجوزها
│   │   ├── service/
│   │   │   └── FloatingTranslatorService.kt  // Foreground service اصلی
│   │   ├── capture/
│   │   │   └── AudioCapture.kt         // ضبط صدای داخلی با MediaProjection
│   │   ├── asr/
│   │   │   ├── SpeechRecognizerEngine.kt   // اینترفیس مشترک ASR
│   │   │   ├── VoskSpeechEngine.kt         // پیاده‌سازی آفلاین سبک (Vosk)
│   │   │   ├── WhisperTurboEngine.kt       // پیاده‌سازی آفلاین باکیفیت (Whisper v3 Turbo / sherpa-onnx)
│   │   │   └── GoogleCloudSpeechEngine.kt  // پیاده‌سازی آنلاین (WebSocket)
│   │   ├── translate/
│   │   │   └── TranslatorManager.kt    // ML Kit فارسی ترجمه
│   │   ├── ui/
│   │   │   ├── MainActivity.kt
│   │   │   └── FloatingOverlay.kt      // پنجره شناور
│   │   └── util/
│   │       ├── AppConfig.kt
│   │       └── Prefs.kt
│   └── res/
│       ├── layout/
│       ├── drawable/
│       ├── values/
│       └── xml/
└── build.gradle.kts
```

## پیش‌نیازها
- اندروید 10 (API 29) به بالا
- Android Studio Hedgehog یا جدیدتر
- JDK 17
- برای حالت Google Cloud: یک API Key از Google Cloud Console با فعال بودن **Speech-to-Text API**

## نحوه ساخت
1. پروژه را در Android Studio باز کنید (`File → Open` و پوشه‌ی `FloatingTranslator` را انتخاب کنید).
2. صبر کنید Gradle sync شود.
3. اگر می‌خواهید از Google Cloud استفاده کنید:
   - در [Google Cloud Console](https://console.cloud.google.com/) یک پروژه بسازید.
   - Speech-to-Text API را Enable کنید.
   - یک API Key بسازید.
   - در اپ، در تب «موتور تشخیص گفتار»، گزینه‌ی «آنلاین» را انتخاب و API Key را وارد کنید.
4. روی دستگاه فیزیکی (نه امولاتور، برای صدا) Run کنید.

⚠️ توجه:
- **ضبط صدای داخلی** روی برخی اپ‌ها (DRM-protected مثل Netflix رسمی، Spotify در بعضی دستگاه‌ها) ممکن است بلاک شود.
- برای تست، ویدیو‌ی YouTube (در مرورگر یا اپ)، TED talk، پادکست، یا هر فایل رسانه‌ای محافظت‌نشده‌ای که انگلیسی/اسپانیایی حرف می‌زند پخش کنید.

## مجوزهای لازم
| مجوز | دلیل |
|------|------|
| `RECORD_AUDIO` | برای دریافت استریم صدا از AudioPlaybackCapture |
| `SYSTEM_ALERT_WINDOW` | نمایش پنجره شناور روی اپ‌های دیگر |
| `FOREGROUND_SERVICE` | اجرای مداوم سرویس |
| `INTERNET` | دانلود مدل‌ها / استفاده از Google Cloud STT |
| `POST_NOTIFICATIONS` | نمایش ناتیفیکیشن سرویس (اندروید 13+) |

## مقایسه موتورهای تشخیص گفتار
| موتور | نوع | حجم مدل | سرعت | کیفیت | نیاز اینترنت |
|-------|-----|---------|------|-------|-------------|
| Vosk small | آفلاین | ~40 MB | ⚡ خیلی سریع | خوب (صدای تمیز) | فقط دانلود اولیه |
| **Whisper v3 Turbo (int8)** | آفلاین | ~150-250 MB | 🟡 متوسط (بسته به CPU) | ⭐⭐⭐⭐⭐ عالی | فقط دانلود اولیه |
| Google Cloud STT | آنلاین | — | ⚡ بسیار سریع | ⭐⭐⭐⭐⭐ عالی | همیشه |

> برای بهترین تجربه، پیشنهاد می‌کنم **Whisper v3 Turbo** را انتخاب کنید — اولین بار حدود ۱۵۰-۲۰۰ مگابایت مدل دانلود می‌شود و سپس کاملاً آفلاین کار می‌کند.
>
> ⚠️ Whisper از نوع chunk-based است (نه streaming واقعی)، بنابراین تأخیر حدود ۱.۵ ثانیه خواهد داشت (مثل زیرنویس زنده یوتیوب). اگر تأخیر صفر می‌خواهید از Google Cloud استفاده کنید.

## محدودیت‌ها و بهبودهای آتی
- ⏳ در دستگاه‌هایی که اپ‌ها اجازه capture نمی‌دهند، می‌توان به‌عنوان fallback از میکروفون استفاده کرد (با حذف `audioPlaybackCaptureConfig` و ساخت AudioRecord معمولی).
- 🧠 می‌توان مدل Whisper فارسی یا Vosk فارسی را برای تشخیص گفتار فارسی به انگلیسی اضافه کرد.
- 🔑 در نسخه‌ی انتشار، به‌جای API Key در کلاینت، از یک سرور میانی (proxy) یا Service Account JWT استفاده کنید تا API Key لو نرود.
- 📝 اضافه کردن history زیرنویس‌ها، تغییر رنگ/اندازه فونت، و موقعیت یادآور پنجره.

## چرخه کار سرویس
```
MainActivity
   │  درخواست مجوزها (Overlay, RecordAudio, Notifications, MediaProjection consent)
   ▼
FloatingTranslatorService (foreground)
   │
   ├─ MediaProjection → AudioCapture (AudioPlaybackCapture)
   │       │  PCM 16kHz mono chunks
   │       ▼
   ├─ SpeechRecognizerEngine (Vosk OR Google Cloud WebSocket)
   │       │  partial/final transcripts
   │       ▼
   ├─ TranslatorManager (ML Kit EN/ES → FA)
   │       │  Persian text
   │       ▼
   └─ FloatingOverlay (WindowManager) → نمایش زنده
```

## استفاده
1. اپ را باز کنید.
2. زبان مبدأ را انتخاب کنید (انگلیسی/اسپانیایی).
3. موتور تشخیص گفتار را انتخاب کنید (Vosk آفلاین یا Google Cloud).
4. روی «شروع ترجمه زنده» بزنید و دسترسی‌های خواسته‌شده را بدهید.
5. در صفحه‌ی کپچر اسکرین، روی «Start now» بزنید.
6. پنجره شناور پایین صفحه نمایان می‌شود. حالا هر رسانه‌ای که پخش کنید (با رعایت محدودیت DRM) صدایش تشخیص داده شده و زیرنویس فارسی نمایش داده می‌شود.
7. برای خروج روی دکمه ✕ در پنجره بزنید یا از ناتیفیکیشن «توقف» را انتخاب کنید.

## لایسنس
این پروژه به‌عنوان نمونه‌ی آموزشی تهیه شده است. استفاده در تولید نیازمند بازبینی امنیتی (مخصوصاً در مورد API Key) و رعایت قوانین استفاده از سرویس‌های شخص ثالث (Google Cloud, Vosk) می‌باشد.
