package com.floatingtranslator.asr

import android.content.Context
import android.util.Log
import com.floatingtranslator.util.AppConfig
import org.vosk.LibVosk
import org.vosk.LogLevel
import org.vosk.Model
import org.vosk.Recognizer
import java.io.Closeable
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.zip.ZipInputStream
import kotlin.concurrent.thread

/**
 * Vosk-based offline streaming recognizer.
 * The model is downloaded from the official Vosk CDN on first use (for the active language)
 * and unzipped into app's filesDir.
 */
class VoskSpeechEngine(private val context: Context) : SpeechRecognizerEngine {

    private var recognizer: Recognizer? = null
    private var model: Model? = null
    private var currentLang: String = ""
    private var listener: SpeechRecognizerEngine.RecognitionListener? = null
    private var worker: Thread? = null
    private val queue = java.util.concurrent.LinkedBlockingQueue<ShortArray>(QUEUE_CAPACITY)
    @Volatile private var running = false

    init {
        runCatching { LibVosk.setLogLevel(LogLevel.INFO) }
    }

    override fun start(languageCode: String, listener: SpeechRecognizerEngine.RecognitionListener) {
        this.listener = listener
        this.currentLang = languageCode
        running = true

        worker = thread(start = true, name = "VoskWorker") {
            try {
                val modelDir = ensureModelAvailable(languageCode)
                val m = Model(modelDir.absolutePath)
                model = m
                val rec = Recognizer(m, AppConfig.SAMPLE_RATE.toFloat())
                recognizer = rec

                while (running) {
                    val audio = try { queue.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS) }
                    catch (_: InterruptedException) { null } ?: continue

                    val bytes = ShortToBytes(audio)
                    if (rec.acceptWaveForm(bytes, bytes.size)) {
                        val result = rec.result
                        val text = parseTextFromJson(result)
                        if (text.isNotBlank()) listener.onFinal(text)
                    } else {
                        val partial = rec.partialResult
                        val text = parseTextFromJson(partial, key = "partial")
                        if (text.isNotBlank()) listener.onPartial(text)
                    }
                }

                // Final flush
                val finalResult = rec.finalResult
                val text = parseTextFromJson(finalResult)
                if (text.isNotBlank()) listener.onFinal(text)
            } catch (e: Exception) {
                Log.e(TAG, "Vosk error", e)
                listener.onError(e.message ?: "Vosk engine error")
            } finally {
                cleanup()
            }
        }
    }

    override fun accept(audio: ShortArray) {
        if (!running) return
        // Drop oldest if queue is full to keep latency low.
        if (!queue.offer(audio)) {
            queue.poll()
            queue.offer(audio)
        }
    }

    override fun stop() {
        running = false
        worker?.join(3000)
        worker = null
        cleanup()
    }

    override fun close() {
        stop()
    }

    private fun cleanup() {
        runCatching { recognizer?.close() }
        recognizer = null
        runCatching { model?.close() }
        model = null
        listener = null
        queue.clear()
    }

    /** Blocks until the model for [lang] is present in filesDir. Downloads & extracts if needed. */
    private fun ensureModelAvailable(lang: String): File {
        val (folderName, url) = when (lang) {
            AppConfig.LANG_SPANISH, "es" -> AppConfig.VOSK_MODEL_ES_FOLDER to AppConfig.VOSK_MODEL_ES_URL
            else -> AppConfig.VOSK_MODEL_EN_FOLDER to AppConfig.VOSK_MODEL_EN_URL
        }
        val targetDir = File(context.filesDir, folderName)
        if (targetDir.exists() && File(targetDir, "am").exists()) return targetDir

        val zipFile = File(context.cacheDir, "$folderName.zip")
        if (!zipFile.exists()) {
            Log.d(TAG, "Downloading Vosk model for $lang from $url")
            URL(url).openStream().use { input ->
                FileOutputStream(zipFile).use { output -> input.copyTo(output) }
            }
        }
        Log.d(TAG, "Extracting model to ${targetDir.absolutePath}")
        targetDir.mkdirs()
        ZipInputStream(zipFile.inputStream()).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val childName = entry.name.removePrefix("$folderName/")
                if (childName.isBlank()) {
                    entry = zis.nextEntry
                    continue
                }
                val outFile = File(targetDir, childName)
                if (entry.isDirectory) {
                    outFile.mkdirs()
                } else {
                    outFile.parentFile?.mkdirs()
                    FileOutputStream(outFile).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return targetDir
    }

    private fun parseTextFromJson(json: String, key: String = "text"): String {
        // Very small JSON parse to avoid pulling a full parser into this thread (though Gson is available).
        val needle = "\"$key\""
        val keyIdx = json.indexOf(needle)
        if (keyIdx < 0) return ""
        val colon = json.indexOf(':', startIndex = keyIdx + needle.length)
        if (colon < 0) return ""
        val quoteStart = json.indexOf('"', startIndex = colon + 1)
        if (quoteStart < 0) return ""
        val quoteEnd = json.indexOf('"', startIndex = quoteStart + 1)
        if (quoteEnd < 0) return ""
        return json.substring(quoteStart + 1, quoteEnd)
    }

    private fun ShortToBytes(shorts: ShortArray): ByteArray {
        val bytes = ByteArray(shorts.size * 2)
        var i = 0
        for (s in shorts) {
            bytes[i++] = s.toByte()
            bytes[i++] = (s.toInt() shr 8).toByte()
        }
        return bytes
    }

    companion object {
        private const val TAG = "VoskSpeechEngine"
        private const val QUEUE_CAPACITY = 120 // ~12 seconds
    }
}
