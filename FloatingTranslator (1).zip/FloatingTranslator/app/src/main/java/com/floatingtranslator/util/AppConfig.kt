package com.floatingtranslator.util

/**
 * Application-wide configuration constants.
 */
object AppConfig {

    // Audio capture / recognition parameters
    const val SAMPLE_RATE = 16000
    const val CHANNEL_CONFIG = android.media.AudioFormat.CHANNEL_IN_MONO
    const val AUDIO_FORMAT = android.media.AudioFormat.ENCODING_PCM_16BIT

    // Source languages for ASR (BCP-47 style tags used by recognition engines)
    const val LANG_ENGLISH = "en-US"
    const val LANG_SPANISH = "es-ES"

    // Target language for translation (ML Kit Translate uses these codes)
    const val TARGET_FARSI = "fa"

    // Notification / foreground service IDs
    const val NOTIFICATION_CHANNEL_ID = "floating_translator_channel"
    const val NOTIFICATION_ID = 1001

    // Vosk model URLs (small models for mobile, English and Spanish)
    // Hosted at the official Vosk models repository.
    const val VOSK_MODEL_EN_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    const val VOSK_MODEL_ES_URL = "https://alphacephei.com/vosk/models/vosk-model-small-es-0.42.zip"

    const val VOSK_MODEL_EN_FOLDER = "vosk-model-small-en-us-0.15"
    const val VOSK_MODEL_ES_FOLDER = "vosk-model-small-es-0.42"

    // Shared prefs
    const val PREFS_NAME = "floating_translator_prefs"
    const val PREF_SOURCE_LANG = "source_lang"
    const val PREF_ASR_ENGINE = "asr_engine"
    const val PREF_GOOGLE_API_KEY = "google_api_key"
}

enum class AsrEngine { VOSK, GOOGLE_CLOUD, WHISPER_TURBO }

enum class ServiceStatus { IDLE, STARTING, CAPTURING, ERROR }
