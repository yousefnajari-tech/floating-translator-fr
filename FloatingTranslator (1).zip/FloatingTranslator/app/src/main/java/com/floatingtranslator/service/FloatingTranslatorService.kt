package com.floatingtranslator.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.floatingtranslator.R
import com.floatingtranslator.asr.GoogleCloudSpeechEngine
import com.floatingtranslator.asr.SpeechRecognizerEngine
import com.floatingtranslator.asr.VoskSpeechEngine
import com.floatingtranslator.asr.WhisperTurboEngine
import com.floatingtranslator.capture.AudioCapture
import com.floatingtranslator.translate.TranslatorManager
import com.floatingtranslator.ui.FloatingOverlay
import com.floatingtranslator.ui.MainActivity
import com.floatingtranslator.util.AppConfig
import com.floatingtranslator.util.AsrEngine
import com.floatingtranslator.util.Prefs
import com.floatingtranslator.util.ServiceStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Foreground service that:
 *  1) Starts with a MediaProjection token from the activity
 *  2) Captures playback audio via AudioPlaybackCapture
 *  3) Streams PCM to the configured ASR engine (Vosk offline or Google Cloud online)
 *  4) Translates finalized transcripts to Persian using ML Kit on-device translation
 *  5) Updates the floating window in real-time
 */
class FloatingTranslatorService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var mediaProjection: MediaProjection? = null
    private var audioCapture: AudioCapture? = null
    private var asrEngine: SpeechRecognizerEngine? = null
    private var translator: TranslatorManager? = null
    private var overlay: FloatingOverlay? = null

    private var sourceLang: String = AppConfig.LANG_ENGLISH

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(AppConfig.NOTIFICATION_ID, buildNotification(getString(R.string.status_starting)))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopSelf(); return START_NOT_STICKY }
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                if (data == null) {
                    Log.e(TAG, "Missing MediaProjection data")
                    stopSelf()
                    return START_NOT_STICKY
                }
                sourceLang = Prefs.getSourceLang(this)
                serviceScope.launch { startPipeline(resultCode, data) }
            }
        }
        return START_NOT_STICKY
    }

    private suspend fun startPipeline(resultCode: Int, data: Intent) {
        try {
            updateNotification(getString(R.string.status_starting))

            // 1) Acquire MediaProjection
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val mp = withContext(Dispatchers.Main) {
                mpm.getMediaProjection(resultCode, data).also { proj ->
                    proj.registerCallback(object : MediaProjection.Callback() {
                        override fun onStop() {
                            Log.i(TAG, "MediaProjection revoked by user; stopping service")
                            this@FloatingTranslatorService.stopSelf()
                        }
                    }, null)
                }
            }
            mediaProjection = mp

            // 2) Initialize translator (ensure model downloaded)
            val tm = TranslatorManager(this)
            translator = tm
            tm.ensureReady(sourceLang)

            // 3) Build ASR engine
            val engineType = Prefs.getAsrEngine(this)
            val engine: SpeechRecognizerEngine = when (engineType) {
                AsrEngine.GOOGLE_CLOUD -> {
                    val key = Prefs.getGoogleApiKey(this)
                    if (key.isBlank()) error("لطفاً API Key گوگل را در تنظیمات وارد کنید")
                    GoogleCloudSpeechEngine(key)
                }
                AsrEngine.WHISPER_TURBO -> WhisperTurboEngine(this)
                AsrEngine.VOSK -> VoskSpeechEngine(this)
            }
            asrEngine = engine

            // 4) Show floating overlay
            val ov = FloatingOverlay(this) { stopSelf() }
            overlay = ov
            withContext(Dispatchers.Main) { ov.show() }

            // 5) Wire ASR callbacks that translate and update UI
            engine.start(sourceLang, object : SpeechRecognizerEngine.RecognitionListener {
                private var lastPartial = ""
                private var translateJob: Job? = null
                // Debounce translation to avoid hammering ML Kit on every partial
                private var pendingPartial: String? = null
                private var lastFinalAt = 0L

                override fun onPartial(text: String) {
                    val cleaned = text.trim()
                    lastPartial = cleaned
                    overlay?.setStatus(getString(R.string.listening))
                    overlay?.setOriginal(cleaned)
                    // Debounce partial translation
                    pendingPartial = cleaned
                    serviceScope.launch {
                        delay(PARTIAL_TRANSLATE_DEBOUNCE_MS)
                        if (pendingPartial == cleaned) {
                            runCatching {
                                val fa = tm.translate(sourceLang, cleaned)
                                if (pendingPartial == cleaned) overlay?.setTranslation(fa)
                            }
                        }
                    }
                }

                override fun onFinal(text: String) {
                    lastFinalAt = System.currentTimeMillis()
                    val cleaned = text.trim()
                    if (cleaned.isBlank()) return
                    overlay?.setStatus(getString(R.string.translating))
                    overlay?.setOriginal(cleaned)
                    translateJob?.cancel()
                    translateJob = serviceScope.launch {
                        runCatching {
                            val fa = tm.translate(sourceLang, cleaned)
                            overlay?.setOriginal(cleaned)
                            overlay?.setTranslation(fa)
                            overlay?.setStatus(getString(R.string.listening))
                        }.onFailure {
                            overlay?.setStatus("خطا: ${it.message}")
                        }
                    }
                }

                override fun onError(message: String) {
                    Log.e(TAG, "ASR error: $message")
                    overlay?.setStatus("خطای تشخیص گفتار: $message")
                }
            })

            // 6) Start capturing internal audio
            val cap = AudioCapture(
                mediaProjection = mp,
                onAudio = { audio -> asrEngine?.accept(audio) },
                onError = { err ->
                    Log.e(TAG, "Capture error", err)
                    overlay?.setStatus("خطای ضبط: ${err.message}")
                }
            )
            audioCapture = cap
            cap.start(serviceScope)

            updateNotification(getString(R.string.status_capturing))
            overlay?.setStatus(getString(R.string.listening))
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start pipeline", e)
            overlay?.setStatus("خطا: ${e.message}")
            updateNotification("خطا: ${e.message}")
            // Give user time to see the error then stop.
            serviceScope.launch {
                delay(8000)
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        runCatching { audioCapture?.stop() }
        audioCapture = null
        runCatching { asrEngine?.close() }
        asrEngine = null
        runCatching { translator?.close() }
        translator = null
        with(serviceScope) {
            launch(Dispatchers.Main) { overlay?.hide() }
            cancel()
        }
        overlay = null
        runCatching { mediaProjection?.stop() }
        mediaProjection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    // --- Notification helpers ---
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(
                AppConfig.NOTIFICATION_CHANNEL_ID,
                getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.channel_desc)
                setShowBadge(false)
            }
            nm.createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pi = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val stopIntent = Intent(this, FloatingTranslatorService::class.java).setAction(ACTION_STOP)
        val stopPi = PendingIntent.getService(
            this, 100, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, AppConfig.NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pi)
            .addAction(0, getString(R.string.stop_service), stopPi)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(AppConfig.NOTIFICATION_ID, buildNotification(text))
    }

    companion object {
        private const val TAG = "FloatingService"
        private const val PARTIAL_TRANSLATE_DEBOUNCE_MS = 400L

        const val ACTION_START = "com.floatingtranslator.action.START"
        const val ACTION_STOP = "com.floatingtranslator.action.STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"

        fun start(context: Context, resultCode: Int, data: Intent) {
            val i = Intent(context, FloatingTranslatorService::class.java)
                .setAction(ACTION_START)
                .putExtra(EXTRA_RESULT_CODE, resultCode)
                .putExtra(EXTRA_DATA, data)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(i)
            } else {
                context.startService(i)
            }
        }

        fun stop(context: Context) {
            context.startService(
                Intent(context, FloatingTranslatorService::class.java).setAction(ACTION_STOP)
            )
        }
    }
}
