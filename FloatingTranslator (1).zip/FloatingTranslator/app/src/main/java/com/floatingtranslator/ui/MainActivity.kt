package com.floatingtranslator.ui

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.RadioButton
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.floatingtranslator.R
import com.floatingtranslator.databinding.ActivityMainBinding
import com.floatingtranslator.service.FloatingTranslatorService
import com.floatingtranslator.util.AppConfig
import com.floatingtranslator.util.AsrEngine
import com.floatingtranslator.util.Prefs
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val mpManager by lazy { getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager }

    // Permission launcher for overlay
    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { checkPermissionsAndStart() }

    // Permission launcher for record-audio / post-notifications
    private val runtimePermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { checkPermissionsAndStart() }

    // MediaProjection consent screen
    private val mediaProjectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
            if (res.resultCode == Activity.RESULT_OK && res.data != null) {
                persistSettings()
                FloatingTranslatorService.start(this, res.resultCode, res.data!!)
                updateUiRunning(true)
            } else {
                setStatus("اجازه ضبط صفحه/صدا لغو شد", R.color.status_error)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Restore persisted settings
        when (Prefs.getSourceLang(this)) {
            AppConfig.LANG_SPANISH -> binding.rbSpanish.isChecked = true
            else -> binding.rbEnglish.isChecked = true
        }
        when (Prefs.getAsrEngine(this)) {
            AsrEngine.GOOGLE_CLOUD -> binding.rbGoogleCloud.isChecked = true
            AsrEngine.WHISPER_TURBO -> binding.rbWhisper.isChecked = true
            else -> binding.rbVosk.isChecked = true
        }
        binding.etApiKey.setText(Prefs.getGoogleApiKey(this))

        // Toggle API key field visibility
        binding.asrEngineGroup.setOnCheckedChangeListener { _, checkedId ->
            binding.apiKeyInputLayout.visibility =
                if (checkedId == R.id.rbGoogleCloud) android.view.View.VISIBLE
                else android.view.View.GONE
        }
        // Trigger initial visibility
        binding.apiKeyInputLayout.visibility =
            if (binding.rbGoogleCloud.isChecked) android.view.View.VISIBLE else android.view.View.GONE

        binding.btnStart.setOnClickListener { onStartClicked() }
        binding.btnStop.setOnClickListener {
            FloatingTranslatorService.stop(this)
            updateUiRunning(false)
            setStatus(getString(R.string.status_idle), R.color.status_ready)
        }

        setStatus(getString(R.string.status_idle), R.color.status_ready)
    }

    private fun onStartClicked() {
        persistSettings()
        if (binding.rbGoogleCloud.isChecked && binding.etApiKey.text.isNullOrBlank()) {
            Snackbar.make(binding.root, "برای حالت Google Cloud لطفاً API Key وارد کنید", Snackbar.LENGTH_LONG).show()
            return
        }
        if (!hasOverlayPermission()) {
            overlayPermissionLauncher.launch(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        checkPermissionsAndStart()
    }

    private fun checkPermissionsAndStart() {
        val needed = mutableListOf<String>()
        needed += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed += Manifest.permission.POST_NOTIFICATIONS
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) !=
                android.content.pm.PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            runtimePermissionLauncher.launch(missing.toTypedArray())
            return
        }
        if (!hasOverlayPermission()) {
            Snackbar.make(binding.root, "مجوز نمایش روی سایر برنامه‌ها لازم است", Snackbar.LENGTH_LONG).show()
            return
        }
        // Launch MediaProjection consent
        setStatus(getString(R.string.status_starting), R.color.status_listening)
        runCatching {
            mediaProjectionLauncher.launch(mpManager.createScreenCaptureIntent())
        }.onFailure {
            setStatus("خطا: ${it.message}", R.color.status_error)
        }
    }

    private fun persistSettings() {
        val sourceLang =
            if (binding.rbSpanish.isChecked) AppConfig.LANG_SPANISH else AppConfig.LANG_ENGLISH
        Prefs.setSourceLang(this, sourceLang)

        val engine = when {
            binding.rbGoogleCloud.isChecked -> AsrEngine.GOOGLE_CLOUD
            binding.rbWhisper.isChecked -> AsrEngine.WHISPER_TURBO
            else -> AsrEngine.VOSK
        }
        Prefs.setAsrEngine(this, engine)

        val key = binding.etApiKey.text?.toString()?.trim().orEmpty()
        Prefs.setGoogleApiKey(this, key)
    }

    private fun hasOverlayPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            Settings.canDrawOverlays(this)
        else {
            val appOps = getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
            val mode = appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_SYSTEM_ALERT_WINDOW,
                android.os.Process.myUid(), packageName
            )
            mode == AppOpsManager.MODE_ALLOWED
        }
    }

    private fun setStatus(text: String, colorRes: Int) {
        binding.tvStatus.text = text
        binding.statusDot.background.setTint(ContextCompat.getColor(this, colorRes))
    }

    private fun updateUiRunning(running: Boolean) {
        binding.btnStart.visibility = if (running) android.view.View.GONE else android.view.View.VISIBLE
        binding.btnStop.visibility = if (running) android.view.View.VISIBLE else android.view.View.GONE
        if (running) setStatus(getString(R.string.status_capturing), R.color.status_ready)
    }
}
