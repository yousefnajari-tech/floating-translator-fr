package com.floatingtranslator.util

import android.content.Context

object Prefs {
    fun get(context: Context) =
        context.getSharedPreferences(AppConfig.PREFS_NAME, Context.MODE_PRIVATE)

    fun getSourceLang(context: Context): String =
        get(context).getString(AppConfig.PREF_SOURCE_LANG, AppConfig.LANG_ENGLISH)!!

    fun setSourceLang(context: Context, lang: String) =
        get(context).edit().putString(AppConfig.PREF_SOURCE_LANG, lang).apply()

    fun getAsrEngine(context: Context): AsrEngine {
        val name = get(context).getString(AppConfig.PREF_ASR_ENGINE, AsrEngine.VOSK.name)
        return try { AsrEngine.valueOf(name!!) } catch (_: Exception) { AsrEngine.VOSK }
    }

    fun setAsrEngine(context: Context, engine: AsrEngine) =
        get(context).edit().putString(AppConfig.PREF_ASR_ENGINE, engine.name).apply()

    fun getGoogleApiKey(context: Context): String =
        get(context).getString(AppConfig.PREF_GOOGLE_API_KEY, "") ?: ""

    fun setGoogleApiKey(context: Context, key: String) =
        get(context).edit().putString(AppConfig.PREF_GOOGLE_API_KEY, key).apply()
}
