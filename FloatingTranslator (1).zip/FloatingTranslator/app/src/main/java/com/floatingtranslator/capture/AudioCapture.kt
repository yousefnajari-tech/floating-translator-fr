package com.floatingtranslator.capture

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.projection.MediaProjection
import android.util.Log
import com.floatingtranslator.util.AppConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * Captures internal audio from other apps' media playback using
 * AudioPlaybackCapture API (requires Android 10+ / API 29 and user consent via MediaProjection).
 *
 * Captured 16-bit PCM @ 16 kHz mono is delivered in [onAudio] chunks as ShortArray.
 * Energy (RMS) is computed per chunk so the ASR layer can skip silence.
 */
class AudioCapture(
    private val mediaProjection: MediaProjection,
    private val onAudio: (ShortArray) -> Unit,
    private val onError: (Exception) -> Unit
) {

    private var audioRecord: AudioRecord? = null
    private var captureJob: Job? = null
    @Volatile private var running = false

    fun start(scope: CoroutineScope) {
        val minBuf = AudioRecord.getMinBufferSize(
            AppConfig.SAMPLE_RATE, AppConfig.CHANNEL_CONFIG, AppConfig.AUDIO_FORMAT
        )
        // Buffer large enough to avoid overrun but small enough for low latency.
        val bufferSize = maxOf(minBuf * 4, 8192)

        val playbackConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .build()

        val record = try {
            AudioRecord.Builder()
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AppConfig.AUDIO_FORMAT)
                        .setSampleRate(AppConfig.SAMPLE_RATE)
                        .setChannelMask(AppConfig.CHANNEL_CONFIG)
                        .build()
                )
                .setAudioPlaybackCaptureConfig(playbackConfig)
                .setBufferSizeInBytes(bufferSize)
                .build()
        } catch (e: SecurityException) {
            onError(e)
            return
        } catch (e: UnsupportedOperationException) {
            onError(e)
            return
        }

        audioRecord = record
        if (record.state != AudioRecord.STATE_INITIALIZED) {
            onError(IllegalStateException("AudioRecord failed to initialize (state=${record.state}). Is another app playing media? Note: apps that disallow playback capture (e.g. DRM-protected content) cannot be captured."))
            return
        }

        running = true
        record.startRecording()
        Log.d(TAG, "AudioRecord started, buffer=$bufferSize")

        captureJob = scope.launch(Dispatchers.IO) {
            val buffer = ByteBuffer.allocateDirect(bufferSize).order(ByteOrder.LITTLE_ENDIAN)
            val chunkSize = AppConfig.SAMPLE_RATE * 2 / 10 // 100ms chunks
            val chunkBuffer = ByteArray(chunkSize)

            try {
                while (isActive && running) {
                    buffer.clear()
                    val read = record.read(buffer, bufferSize)
                    if (read <= 0) continue

                    buffer.rewind()
                    val ba = ByteArray(read)
                    buffer.get(ba, 0, read)

                    // Split into smaller ~100ms chunks and stream out.
                    var offset = 0
                    while (offset < ba.size && isActive) {
                        val len = minOf(chunkSize, ba.size - offset)
                        System.arraycopy(ba, offset, chunkBuffer, 0, len)
                        offset += len

                        if (isSilent(chunkBuffer, len)) continue

                        val shorts = ShortArray(len / 2)
                        ByteBuffer.wrap(chunkBuffer, 0, len)
                            .order(ByteOrder.LITTLE_ENDIAN)
                            .asShortBuffer()
                            .get(shorts)
                        onAudio(shorts)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Capture loop error", e)
                onError(e)
            } finally {
                runCatching { record.stop() }
                runCatching { record.release() }
                audioRecord = null
                Log.d(TAG, "AudioCapture stopped")
            }
        }
    }

    fun stop() {
        running = false
        captureJob?.cancel()
        captureJob = null
        audioRecord?.let { rec ->
            runCatching { rec.stop() }
            runCatching { rec.release() }
        }
        audioRecord = null
    }

    private fun isSilent(bytes: ByteArray, len: Int): Boolean {
        // Basic silence detection: if peak absolute amplitude is low, skip chunk.
        var peak = 0
        var i = 0
        while (i < len - 1) {
            val s = ((bytes[i + 1].toInt() shl 8) or (bytes[i].toInt() and 0xFF)).toShort()
            val a = abs(s.toInt())
            if (a > peak) peak = a
            if (peak > SILENCE_THRESHOLD) return false
            i += 2
        }
        return peak < SILENCE_THRESHOLD
    }

    companion object {
        private const val TAG = "AudioCapture"
        private const val SILENCE_THRESHOLD = 350 // ~ -45 dBFS for 16-bit PCM
    }
}
