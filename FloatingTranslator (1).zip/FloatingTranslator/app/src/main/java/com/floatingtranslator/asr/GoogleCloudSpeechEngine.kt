package com.floatingtranslator.asr

import android.util.Base64
import android.util.Log
import com.floatingtranslator.util.AppConfig
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.Closeable
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.TimeUnit

/**
 * Streaming recognition using Google Cloud Speech-to-Text v1p1beta1 via WebSocket (bidirectional).
 *
 * API key is passed as a query parameter (not ideal for production; a signed credential / service account
 * is preferred). A production build should proxy these calls through your own server.
 */
class GoogleCloudSpeechEngine(private val apiKey: String) : SpeechRecognizerEngine {

    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS) // long-lived stream
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()
    private var webSocket: WebSocket? = null
    private var listener: SpeechRecognizerEngine.RecognitionListener? = null
    private var scope: CoroutineScope? = null

    private val audioQueue = LinkedBlockingQueue<ShortArray>(QUEUE_CAPACITY)
    private var senderJob: Job? = null

    @Volatile private var started = false

    override fun start(languageCode: String, listener: SpeechRecognizerEngine.RecognitionListener) {
        this.listener = listener
        started = true

        val url = "wss://speech.googleapis.com/v1p1beta1/speech:streamingRecognize?key=$apiKey"
        val request = Request.Builder().url(url).build()
        webSocket = client.newWebSocket(request, WsListener())

        // Send the initial StreamingRecognitionConfig
        val config = JsonObject().apply {
            add("streamingConfig", JsonObject().apply {
                add("config", JsonObject().apply {
                    addProperty("encoding", "LINEAR16")
                    addProperty("sampleRateHertz", AppConfig.SAMPLE_RATE)
                    addProperty("languageCode", languageCode)
                    addProperty("enableAutomaticPunctuation", true)
                    addProperty("model", "default")
                })
                addProperty("interimResults", true)
                addProperty("singleUtterance", false)
            })
        }
        webSocket?.send(gson.toJson(config))

        // Send audio chunks from a dedicated coroutine
        val scope0 = CoroutineScope(Dispatchers.IO + Job())
        scope = scope0
        senderJob = scope0.launch {
            try {
                // Send audio in ~100ms chunks, base64 encoded.
                while (isActive && started) {
                    val chunk = try {
                        audioQueue.poll(100, TimeUnit.MILLISECONDS)
                    } catch (_: InterruptedException) { null }
                    if (chunk != null) {
                        val bytes = ShortToBytes(chunk)
                        val b64 = Base64.encodeToString(bytes, Base64.NO_WRAP)
                        val msg = JsonObject().apply {
                            add("audioContent", com.google.gson.JsonPrimitive(b64))
                        }
                        webSocket?.send(gson.toJson(msg))
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Sender failed", e)
                listener.onError(e.message ?: "Network sender error")
            }
        }
    }

    override fun accept(audio: ShortArray) {
        if (!started) return
        if (!audioQueue.offer(audio)) {
            audioQueue.poll() // drop oldest to keep latency bounded
            audioQueue.offer(audio)
        }
    }

    override fun stop() {
        started = false
        // Signal end of stream
        runCatching {
            val closeMsg = JsonObject().apply { addProperty("endOfStream", true) }
            webSocket?.send(gson.toJson(closeMsg))
        }
        // Give server a moment to return final results then close.
        Thread.sleep(600)
        runCatching { webSocket?.close(1000, "client closing") }
        senderJob?.cancel()
        senderJob = null
        scope = null
        webSocket = null
        audioQueue.clear()
        listener = null
    }

    override fun close() {
        stop()
        runCatching { client.dispatcher.executorService.shutdown() }
    }

    private inner class WsListener : WebSocketListener() {
        override fun onOpen(webSocket: WebSocket, response: Response) {
            Log.d(TAG, "WebSocket opened to Google STT")
        }

        override fun onMessage(webSocket: WebSocket, text: String) {
            try {
                val root = gson.fromJson(text, JsonObject::class.java)
                if (root.has("error")) {
                    val err = root.getAsJsonObject("error")?.get("message")?.asString ?: "STT error"
                    Log.e(TAG, "Google STT error: $err")
                    listener?.onError(err)
                    return
                }
                val results = root.getAsJsonArray("results") ?: return
                for (el in results) {
                    val r = el.asJsonObject
                    val isFinal = r.get("isFinal")?.asBoolean ?: false
                    val alternatives = r.getAsJsonArray("alternatives") ?: continue
                    val first = alternatives.firstOrNull()?.asJsonObject ?: continue
                    val transcript = first.get("transcript")?.asString ?: continue
                    if (isFinal) listener?.onFinal(transcript)
                    else listener?.onPartial(transcript)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Parse error", e)
            }
        }

        override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
            Log.e(TAG, "WS failure", t)
            listener?.onError(t.message ?: "WebSocket error")
            started = false
        }

        override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
            webSocket.close(1000, null)
        }
    }

    private fun ShortToBytes(shorts: ShortArray): ByteArray {
        val bytes = ByteArray(shorts.size * 2)
        var i = 0
        for (s in shorts) {
            bytes[i++] = s.toByte()
            bytes[i++] = (s.toInt() shr 8).toByte()
        }
        return bytes
    }

    companion object {
        private const val TAG = "GoogleCloudSTT"
        private const val QUEUE_CAPACITY = 200
    }
}
