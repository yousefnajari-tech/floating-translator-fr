package com.floatingtranslator.ui

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.floatingtranslator.R
import com.floatingtranslator.databinding.FloatingSubtitleBinding
import kotlin.math.abs

/**
 * Draggable floating window that displays the original recognized text and its Persian translation.
 * Call [show] after obtaining SYSTEM_ALERT_WINDOW permission, and [hide] to remove it.
 */
class FloatingOverlay(
    private val context: Context,
    private val onClose: () -> Unit
) {
    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var binding: FloatingSubtitleBinding? = null
    private var view: View? = null

    private var initialX = 0
    private var initialY = 0
    private var touchX = 0f
    private var touchY = 0f

    fun show() {
        if (view != null) return
        val b = FloatingSubtitleBinding.inflate(LayoutInflater.from(context))
        binding = b
        val typeFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            typeFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 120
        }

        // Drag handling
        b.root.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    touchX = event.rawX
                    touchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchX).toInt()
                    val dy = (event.rawY - touchY).toInt()
                    if (abs(dx) > 3 || abs(dy) > 3) {
                        params.x = initialX + dx
                        params.y = initialY + dy
                        params.gravity = Gravity.TOP or Gravity.START
                        runCatching { windowManager.updateViewLayout(b.root, params) }
                    }
                    true
                }
                else -> false
            }
        }

        b.btnClose.setOnClickListener { onClose() }

        windowManager.addView(b.root, params)
        view = b.root
        setStatus(context.getString(R.string.waiting_for_speech))
        clear()
    }

    fun hide() {
        val v = view ?: return
        runCatching { windowManager.removeView(v) }
        view = null
        binding = null
    }

    fun setStatus(text: String) {
        binding?.tvListening?.text = text
    }

    fun setOriginal(text: String) {
        binding?.tvOriginal?.text = text
    }

    fun setTranslation(text: String) {
        binding?.tvTranslation?.text = text
    }

    fun clear() {
        setOriginal("")
        setTranslation("")
    }
}
