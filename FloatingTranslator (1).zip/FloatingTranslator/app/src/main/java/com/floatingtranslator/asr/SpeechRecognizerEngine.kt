package com.floatingtranslator.asr

/**
 * Unified streaming speech recognition interface.
 * Implementations accept chunks of 16-bit PCM mono @ 16 kHz and emit partial/final transcripts.
 */
interface SpeechRecognizerEngine {

    /**
     * Start a recognition session. May be called once; call [stop] to end and re-start for a new session.
     * @param languageCode BCP-47 language code (e.g. en-US, es-ES).
     */
    fun start(languageCode: String, listener: RecognitionListener)

    /** Feed a PCM chunk (16-bit LE mono at 16 kHz). Safe to call from an IO thread. */
    fun accept(audio: ShortArray)

    /** End the session. Implementations should flush and deliver any final hypothesis. */
    fun stop()

    /** Release all resources. */
    fun close()

    interface RecognitionListener {
        /** Called for interim (non-final) results while user is speaking. */
        fun onPartial(text: String)
        /** Called for a finalized segment / sentence. */
        fun onFinal(text: String)
        /** Called when the engine encounters an unrecoverable error. */
        fun onError(message: String)
    }
}
