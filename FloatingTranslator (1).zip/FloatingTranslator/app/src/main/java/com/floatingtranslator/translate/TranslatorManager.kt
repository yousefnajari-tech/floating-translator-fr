package com.floatingtranslator.translate

import android.content.Context
import android.util.Log
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.Closeable
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/**
 * Manages ML Kit on-device translators for English -> Persian and Spanish -> Persian.
 * Models are downloaded on first use when the device is on Wi-Fi; call [ensureReady] before translating.
 */
class TranslatorManager(private val context: Context) : Closeable {

    private val translators = HashMap<String, Translator>(2)

    private fun sourceTag(lang: String): String = when (lang) {
        "en-US", "en" -> TranslateLanguage.ENGLISH
        "es-ES", "es" -> TranslateLanguage.SPANISH
        else -> TranslateLanguage.ENGLISH
    }

    private fun getOrCreate(sourceLang: String): Translator {
        val key = sourceTag(sourceLang)
        return translators.getOrPut(key) {
            val options = TranslatorOptions.builder()
                .setSourceLanguage(key)
                .setTargetLanguage(TranslateLanguage.PERSIAN)
                .build()
            Translation.getClient(options)
        }
    }

    /**
     * Makes sure the on-device model for the given source language is downloaded.
     * Throws if download fails or is cancelled.
     */
    suspend fun ensureReady(sourceLang: String) {
        val translator = getOrCreate(sourceLang)
        val conditions = DownloadConditions.Builder()
            .requireWifi()
            .build()
        suspendCancellableCoroutine { cont ->
            translator.downloadModelIfNeeded(conditions)
                .addOnSuccessListener {
                    Log.d(TAG, "ML Kit model ready for $sourceLang")
                    if (cont.isActive) cont.resume(Unit)
                }
                .addOnFailureListener { err ->
                    Log.e(TAG, "Model download failed for $sourceLang", err)
                    if (cont.isActive) cont.resumeWithException(err)
                }
        }
    }

    suspend fun translate(sourceLang: String, text: String): String {
        if (text.isBlank()) return ""
        val translator = getOrCreate(sourceLang)
        return suspendCancellableCoroutine { cont ->
            translator.translate(text)
                .addOnSuccessListener { result ->
                    if (cont.isActive) cont.resume(result)
                }
                .addOnFailureListener { err ->
                    Log.e(TAG, "Translation failed", err)
                    if (cont.isActive) cont.resumeWithException(err)
                }
        }
    }

    override fun close() {
        translators.values.forEach { runCatching { it.close() } }
        translators.clear()
    }

    companion object {
        private const val TAG = "TranslatorManager"
    }
}
