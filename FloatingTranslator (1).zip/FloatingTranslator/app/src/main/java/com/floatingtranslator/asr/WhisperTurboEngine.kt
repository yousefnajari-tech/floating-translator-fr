package com.floatingtranslator.asr

import android.content.Context
import android.util.Log
import com.floatingtranslator.util.AppConfig
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineStream
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.util.zip.ZipInputStream
import java.util.concurrent.LinkedBlockingQueue

/**
 * Whisper v3 Turbo offline engine powered by sherpa-onnx (ONNX Runtime).
 *
 * Whisper is chunk-based rather than fully streaming; we emulate live captioning by:
 *   - Buffering incoming PCM in a rolling window
 *   - Running inference every [STEP_MS] ms
 *   - Using VAD-style energy gating + committed-segment tracking to produce partial/final results
 *
 * Supported models (downloaded on first use to app's filesDir):
 *   - English-only : Whisper v3 Turbo small-distil (int8) — fast, high quality
 *   - Spanish/EN   : Whisper v3 Turbo multilingual (int8)
 *
 * Download URLs come from the official k2-fsa Hugging Face repository of sherpa-onnx-ready Whisper models.
 */
class WhisperTurboEngine(private val context: Context) : SpeechRecognizerEngine {

    private var recognizer: OfflineRecognizer? = null
    private var listener: SpeechRecognizerEngine.RecognitionListener? = null
    private var whisperLang: String = "en"
    private val audioQueue = LinkedBlockingQueue<ShortArray>(QUEUE_CAPACITY)
    private var engineJob: Job? = null
    @Volatile private var running = false
    @Volatile private var lastCommitted = ""

    private val bufferLock = Any()
    private var rollingBuffer = ShortArray(0)

    override fun start(languageCode: String, listener: SpeechRecognizerEngine.RecognitionListener) {
        this.listener = listener
        this.whisperLang = when {
            languageCode.startsWith("es") -> "es"
            else -> "en"
        }
        running = true
        lastCommitted = ""
        synchronized(bufferLock) { rollingBuffer = ShortArray(0) }

        engineJob = CoroutineScope(Dispatchers.IO + Job()).launch {
            try {
                listener.onPartial("در حال آماده‌سازی مدل Whisper v3 Turbo…")
                val modelDir = ensureModelAvailable(whisperLang)

                val encoder = File(modelDir, "encoder.int8.onnx")
                val decoder = File(modelDir, "decoder.int8.onnx")
                val tokens = File(modelDir, "tokens.txt")
                require(encoder.exists() && decoder.exists() && tokens.exists()) {
                    "فایل‌های مدل Whisper کامل نیستند"
                }

                val whisperCfg = OfflineWhisperModelConfig(
                    encoder = encoder.absolutePath,
                    decoder = decoder.absolutePath,
                    language = whisperLang,
                    task = "transcribe",
                    tailPaddings = -1
                )
                val modelCfg = OfflineModelConfig(
                    whisper = whisperCfg,
                    tokens = tokens.absolutePath,
                    modelType = "whisper",
                    numThreads = Runtime.getRuntime().availableProcessors().coerceAtMost(4),
                    debug = false
                )
                val featCfg = FeatureConfig(sampleRate = AppConfig.SAMPLE_RATE, featureDim = 80)
                val recCfg = OfflineRecognizerConfig(
                    modelConfig = modelCfg,
                    featConfig = featCfg
                )
                val rec = OfflineRecognizer(assetManager = null, config = recCfg)
                recognizer = rec

                // Audio consumer
                val consumer = launch {
                    while (isActive && running) {
                        val chunk = try {
                            audioQueue.poll(200, java.util.concurrent.TimeUnit.MILLISECONDS)
                        } catch (_: InterruptedException) { null }
                        if (chunk != null) {
                            synchronized(bufferLock) {
                                val nb = ShortArray(rollingBuffer.size + chunk.size)
                                System.arraycopy(rollingBuffer, 0, nb, 0, rollingBuffer.size)
                                System.arraycopy(chunk, 0, nb, rollingBuffer.size, chunk.size)
                                // Cap window
                                val max = MAX_CONTEXT_MS * AppConfig.SAMPLE_RATE / 1000
                                if (nb.size > max) {
                                    val trimmed = ShortArray(max)
                                    System.arraycopy(nb, nb.size - max, trimmed, 0, max)
                                    rollingBuffer = trimmed
                                } else {
                                    rollingBuffer = nb
                                }
                            }
                        }
                    }
                }

                val minSamples = MIN_CHUNK_MS * AppConfig.SAMPLE_RATE / 1000
                val stepSamples = STEP_MS * AppConfig.SAMPLE_RATE / 1000
                var lastProcessedSamples = 0

                while (isActive && running) {
                    delay(STEP_MS.toLong())
                    var pcm: ShortArray
                    synchronized(bufferLock) { pcm = rollingBuffer.copyOf() }
                    if (pcm.size < minSamples) continue
                    if (pcm.size - lastProcessedSamples < stepSamples / 2) continue
                    lastProcessedSamples = pcm.size

                    // Skip if mostly silent to save CPU
                    if (isMostlySilent(pcm)) continue

                    val floats = FloatArray(pcm.size) { i -> pcm[i].toFloat() / 32768f }

                    val stream: OfflineStream = rec.createStream()
                    stream.acceptWaveform(floats, AppConfig.SAMPLE_RATE)
                    val t0 = System.currentTimeMillis()
                    rec.decode(stream)
                    val dt = System.currentTimeMillis() - t0
                    val result = rec.getResult(stream)
                    val fullText = result.text?.trim().orEmpty()
                    stream.release()

                    if (fullText.isNotBlank()) {
                        // Emit partial update with full current text
                        val combined = if (lastCommitted.isNotEmpty()) "$lastCommitted $fullText" else fullText
                        listener.onPartial(combined.trim())

                        // Finalize "stable" prefix: once the buffer has grown large enough, commit the first half.
                        if (pcm.size > COMMIT_MS * AppConfig.SAMPLE_RATE / 1000 && fullText.length > 10) {
                            val commitPoint = (fullText.length * 0.6).toInt()
                            val finalPiece = fullText.substring(0, commitPoint).trim()
                            if (finalPiece.isNotBlank()) {
                                listener.onFinal(finalPiece)
                                lastCommitted = if (lastCommitted.isNotEmpty()) "$lastCommitted $finalPiece" else finalPiece
                            }
                            // Trim buffer by the proportion committed
                            val keepSamples = pcm.size * (1 - commitPoint.toFloat() / (lastCommitted.length + 1).coerceAtLeast(1))
                            val keep = keepSamples.toInt().coerceAtLeast(minSamples).coerceAtMost(pcm.size)
                            synchronized(bufferLock) {
                                val trimmed = ShortArray(pcm.size - keep)
                                System.arraycopy(pcm, keep, trimmed, 0, trimmed.size)
                                rollingBuffer = trimmed
                                lastProcessedSamples = trimmed.size
                            }
                        }
                    }
                    Log.d(TAG, "Inference: ${pcm.size} samples, dt=${dt}ms, text=${fullText.take(60)}")
                }
                consumer.cancel()
            } catch (e: Exception) {
                Log.e(TAG, "Whisper engine error", e)
                listener?.onError("Whisper: ${e.message}")
            }
        }
    }

    override fun accept(audio: ShortArray) {
        if (!running) return
        if (!audioQueue.offer(audio)) {
            audioQueue.poll()
            audioQueue.offer(audio)
        }
    }

    override fun stop() {
        running = false
        engineJob?.cancel()
        engineJob = null
        synchronized(bufferLock) { rollingBuffer = ShortArray(0) }
        runCatching { recognizer?.release() }
        recognizer = null
        listener = null
        audioQueue.clear()
    }

    override fun close() = stop()

    private fun isMostlySilent(pcm: ShortArray): Boolean {
        var peak = 0
        var energy = 0.0
        for (s in pcm) {
            val a = kotlin.math.abs(s.toInt())
            if (a > peak) peak = a
            energy += a * a
        }
        val rms = kotlin.math.sqrt(energy / pcm.size)
        return peak < PEAK_THRESHOLD || rms < RMS_THRESHOLD
    }

    /**
     * Downloads the int8-quantized Whisper v3 Turbo model for the requested language and unzips into filesDir.
     * Models are the sherpa-onnx-prepared tarballs from Hugging Face (encoder.int8.onnx, decoder.int8.onnx, tokens.txt).
     */
    private fun ensureModelAvailable(lang: String): File {
        val (folder, url) = if (lang == "es") {
            // Multilingual distil-whisper for Spanish (works for en too)
            "sherpa-onnx-whisper-small-v3-turbo-int8" to
                "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-small-v3-turbo.tar.bz2"
        } else {
            // English-only distil-whisper — smaller & faster
            "sherpa-onnx-whisper-distil-small-en-int8" to
                "https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-distil-small.en.tar.bz2"
        }
        val dir = File(context.filesDir, folder)
        if (dir.exists() && File(dir, "encoder.int8.onnx").exists() && File(dir, "tokens.txt").exists()) {
            return dir
        }
        dir.mkdirs()

        val archiveExt = if (url.endsWith(".zip")) "zip" else "tar.bz2"
        val archive = File(context.cacheDir, "$folder.$archiveExt")
        listener?.onPartial("در حال دانلود مدل Whisper v3 Turbo (~200MB)…")
        if (!archive.exists()) {
            URL(url).openStream().use { input ->
                FileOutputStream(archive).use { output ->
                    val buf = ByteArray(128 * 1024)
                    var read: Int
                    while (input.read(buf).also { read = it } > 0) output.write(buf, 0, read)
                }
            }
        }

        listener?.onPartial("در حال استخراج مدل…")
        val parentDir = dir.parentFile!!
        when (archiveExt) {
            "zip" -> {
                ZipInputStream(archive.inputStream()).use { zis ->
                    var entry = zis.nextEntry
                    while (entry != null) {
                        val name = entry.name.substringAfter('/')
                        if (name.isBlank()) { zis.closeEntry(); entry = zis.nextEntry; continue }
                        val out = File(parentDir, entry.name)
                        if (entry.isDirectory) out.mkdirs()
                        else {
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { zis.copyTo(it) }
                        }
                        zis.closeEntry()
                        entry = zis.nextEntry
                    }
                }
            }
            "tar.bz2" -> {
                BZip2CompressorInputStream(BufferedInputStream(archive.inputStream())).use { bz ->
                    TarArchiveInputStream(bz).use { tar ->
                        var entry = tar.nextTarEntry
                        while (entry != null) {
                            val out = File(parentDir, entry.name)
                            if (entry.isDirectory) {
                                out.mkdirs()
                            } else {
                                out.parentFile?.mkdirs()
                                FileOutputStream(out).use { tar.copyTo(it) }
                            }
                            entry = tar.nextTarEntry
                        }
                    }
                }
            }
        }
        return dir
    }

    companion object {
        private const val TAG = "WhisperTurboEngine"
        private const val QUEUE_CAPACITY = 200
        private const val STEP_MS = 1500        // Inference every 1.5 s
        private const val MIN_CHUNK_MS = 1000
        private const val MAX_CONTEXT_MS = 10_000 // 10 s rolling window
        private const val COMMIT_MS = 5000     // Commit ~60% oldest text after 5 s
        private const val PEAK_THRESHOLD = 250
        private const val RMS_THRESHOLD = 80.0
        private val DevNull = java.io.OutputStream() { override fun write(b: Int) {} }
    }
}
