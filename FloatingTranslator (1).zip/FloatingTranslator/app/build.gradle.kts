plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.floatingtranslator"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.floatingtranslator"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        // Vosk native libraries
        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.lifecycle:lifecycle-service:2.7.0")

    // Google ML Kit - On-device Translation
    implementation("com.google.mlkit:translate:17.0.2")

    // Vosk - offline speech recognition
    implementation("com.alphacephei:vosk-android:0.3.47")

    // OkHttp for Google Cloud STT streaming
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // sherpa-onnx (JitPack): on-device speech recognition including Whisper v3 Turbo / distil-whisper.
    // Prebuilt AAR with native libs for ARMv7, ARM64, x86_64 — no NDK setup required.
    implementation("com.github.k2-fsa:sherpa-onnx-android:v1.10.35")

    // Gson for JSON
    implementation("com.google.code.gson:gson:2.10.1")

    // Apache Commons Compress for extracting .tar.bz2 model archives
    implementation("org.apache.commons:commons-compress:1.26.1")

    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3")
}
